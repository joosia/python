# Make a function called "compareNumbers" which takes two parameters,
# compares them and returns the greater number

def compareNumbers(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2
