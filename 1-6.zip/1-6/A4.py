char = "AA"
space = " "
mult = 9

for i in range(0,10):
    print space*mult, char
    mult-=1
    char +="AA"
