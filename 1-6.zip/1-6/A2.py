for greeting in "Hello World":
    print greeting
