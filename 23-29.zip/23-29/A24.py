
def calculator (str, num1, num2):
    if str == "add":
        return num1 + num2
    elif str == "sub":
        return num1 - num2
    elif str == "multiply":
        return num1 * num2
    else:
        return None
