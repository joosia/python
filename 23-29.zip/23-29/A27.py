import random
print random.randint(0, 10)
